-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2024 at 11:13 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pmc_admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(255) NOT NULL,
  `branch_address` varchar(255) NOT NULL,
  `branch_tel` varchar(255) NOT NULL,
  `branch_mob` varchar(255) NOT NULL,
  `branch_fax` varchar(255) NOT NULL,
  `branch_email` varchar(255) NOT NULL,
  `branch_status` tinyint(1) NOT NULL DEFAULT 0,
  `branch_sort` int(11) NOT NULL DEFAULT 0,
  `branch_date_update` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `branch_date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `branch_name`, `branch_address`, `branch_tel`, `branch_mob`, `branch_fax`, `branch_email`, `branch_status`, `branch_sort`, `branch_date_update`, `branch_date_created`) VALUES
(1, 'Head Office', '200 C. Raymundo Avenue Caniogan, Pasig City 1606 Philippines', '+63 (2) 8656 6888', '+63 (969) 3156888', '+63 (2) 8656 4981', 'info@pmc.ph', 1, 0, '2024-04-12 16:20:13', '2024-04-12 14:23:35'),
(3, 'Bacolod', 'Room 203 2nd Floor JL Bldg., Burgos St. Brgy 19, Bacolod City', '(34) 458-3139', '', '(34) 433-6939', 'pmc-bacolod@pmcgroup.com', 1, 0, '2024-04-16 15:28:15', '2024-04-12 16:21:26'),
(4, 'Cagayan De Oro', 'Unit 8, 2nd Floor Montblanc Bldg., No. 848 Burgos-Chaves St., Cagayan de Oro', '(88) 856-4983', '', '(88) 856-4983', 'pmc-cdo@pmcgroup.com', 1, 0, '2024-04-16 15:28:28', '2024-04-12 16:22:19');

-- --------------------------------------------------------

--
-- Table structure for table `careers`
--

CREATE TABLE `careers` (
  `careers_id` int(11) NOT NULL,
  `careers_title` varchar(255) NOT NULL,
  `careers_subtitle` varchar(255) NOT NULL,
  `careers_mailto` varchar(255) NOT NULL,
  `careers_content` longtext NOT NULL,
  `career_img` varchar(255) NOT NULL,
  `careers_status` tinyint(1) NOT NULL DEFAULT 0,
  `careers_date_update` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `careers_date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `careers`
--

INSERT INTO `careers` (`careers_id`, `careers_title`, `careers_subtitle`, `careers_mailto`, `careers_content`, `career_img`, `careers_status`, `careers_date_update`, `careers_date_created`) VALUES
(1, 'Non quis consectetur', 'Aspernatur eius qui ', 'fydimyqoni@mailinator.com', '&lt;p&gt;Test without image&lt;/p&gt;', 'n/a', 1, '2024-02-29 15:16:08', '2024-02-21 16:27:23'),
(2, 'Quia et soluta sed d', 'At nesciunt digniss', 'noxih@mailinator.com', '&lt;p&gt;Test with Image&lt;/p&gt;', 'image_2023_12_13T05_31_25_014Z.png', 0, '2024-04-16 09:08:04', '2024-02-21 16:27:41'),
(5, 'Sit ipsam quis repr', 'Non et porro et omni', 'totub@mailinator.com', '&lt;p&gt;Test with images&lt;/p&gt;', 'JEROME2023.png', 1, '2024-03-01 15:31:34', '2024-02-23 10:49:21'),
(8, 'Accusamus aliqua Fu', 'Et nostrud eius in s', 'sicezecug@mailinator.com', '&lt;p&gt;Sed venenatis massa et ex efficitur, a maximus neque ultrices. Cras sem lorem, malesuada in varius eget, egestas ut erat. Integer eu luctus arcu, vitae varius sem. Nam vulputate porttitor ligula, vitae porttitor sem sagittis id. Fusce rutrum odio et lacus consectetur, in porttitor ipsum ultrices. Fusce scelerisque massa congue magna pretium scelerisque.&lt;/p&gt;', 'Capture.JPG', 1, '2024-04-16 09:07:47', '2024-02-23 14:59:16'),
(10, 'Voluptate fugit aut', 'Reprehenderit quasi ', 'musygy@mailinator.com', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lectus purus, maximus non fermentum vel, tincidunt vitae sem. Cras finibus eros a diam rhoncus, fermentum pellentesque nunc tempus. Vivamus sed turpis ornare, maximus sapien a, mattis sapien. Nam ut est orci. Quisque ac cursus nisi. Morbi fringilla ligula id sem varius, quis pellentesque est dignissim. Nulla nec ante sed tellus sollicitudin pretium. Donec varius posuere elit, et condimentum ex ultricies vitae. Suspendisse nec nunc eget purus iaculis laoreet.&lt;/p&gt;&lt;p&gt;Nullam porta malesuada congue. Maecenas fringilla justo sapien, quis egestas nulla consectetur sed. Donec commodo dapibus ipsum quis pellentesque. Aenean et leo in nulla tincidunt dignissim at eget erat. Etiam eget leo scelerisque, facilisis nunc id, lobortis diam. Proin ut venenatis ex. Nulla pulvinar porta neque, eu vestibulum felis sodales egestas. Maecenas metus erat, pharetra et nulla eu, consectetur faucibus magna. Etiam ante elit, vulputate eget varius nec, tempus a magna. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Aenean leo tellus, sagittis id dictum non, tincidunt nec tortor.&lt;/p&gt;', 'n/a', 1, '2024-04-16 09:08:15', '2024-02-28 16:57:08'),
(11, 'Nihil nihil numquam ', 'Excepteur anim venia', 'dimenepori@mailinator.com', '&lt;h2&gt;Test Title&lt;/h2&gt;&lt;p&gt;Morbi ac enim ullamcorper risus bibendum varius. Nulla vulputate elit quis libero pharetra rutrum. Suspendisse rhoncus ligula at sapien congue elementum. Nulla rhoncus elit eget fermentum fermentum. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Ut convallis neque vel tincidunt gravida. Fusce metus tellus, lacinia in odio a, ullamcorper interdum massa. Quisque cursus arcu et imperdiet rutrum.&lt;/p&gt;&lt;ul&gt;&lt;li&gt;Praesent suscipit dolor a tellus suscipit, a viverra arcu hendrerit.&lt;/li&gt;&lt;li&gt;Cras tempus nibh at diam fringilla varius.&lt;/li&gt;&lt;li&gt;In ut justo eleifend nisl porttitor posuere at nec nulla.&lt;/li&gt;&lt;li&gt;Praesent suscipit dolor a tellus suscipit, a viverra arcu hendrerit.&lt;/li&gt;&lt;li&gt;Cras tempus nibh at diam fringilla varius.&lt;/li&gt;&lt;li&gt;In ut justo eleifend nisl porttitor posuere at nec nulla.&lt;/li&gt;&lt;/ul&gt;', 'features-5.png', 1, '2024-03-01 09:32:41', '2024-03-01 09:27:56');

-- --------------------------------------------------------

--
-- Table structure for table `news_and_events`
--

CREATE TABLE `news_and_events` (
  `news_events_id` int(11) NOT NULL,
  `news_events_section` varchar(255) NOT NULL,
  `news_events_title` varchar(255) NOT NULL,
  `news_events_subtitle` varchar(255) NOT NULL,
  `news_events_upload_date` datetime NOT NULL,
  `news_events_content` longtext NOT NULL,
  `news_events_link` varchar(255) NOT NULL,
  `news_events_status` tinyint(1) NOT NULL DEFAULT 0,
  `news_events_date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_link` varchar(255) NOT NULL,
  `page_status` tinyint(1) NOT NULL DEFAULT 0,
  `page_date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `user_type` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `status`, `user_type`, `date_created`) VALUES
(12, 'admin', '1234', 'cpascual107@gmail.com', 1, 'admin', '2024-02-06 16:00:45'),
(35, 'wicosi', 'Pa$$w0rd!', 'cusi@mailinator.com', 1, 'user', '2024-02-07 11:39:32'),
(36, 'dyjuhohysi', 'Pa$$w0rd!', 'vysite@mailinator.com', 1, 'user', '2024-02-07 15:47:29'),
(42, 'lexiham', 'Pa$$w0rd!', 'soqiryqu@mailinator.com', 1, 'user', '2024-02-08 09:57:02'),
(44, 'qamezad', 'Pa$$w0rd!', 'gacobaty@mailinator.com', 1, 'admin', '2024-02-08 16:27:25'),
(45, 'noxuquz', 'Pa$$w0rd!', 'gadoro@mailinator.com', 0, 'user', '2024-02-16 10:16:31'),
(46, 'noxuquz', 'Pa$$w0rd!', 'gadoro@mailinator.com', 0, 'user', '2024-02-16 10:16:31'),
(47, 'noxuquz', 'Pa$$w0rd!', 'gadoro@mailinator.com', 0, 'user', '2024-02-16 10:16:31'),
(48, 'cadehuxeh', 'Pa$$w0rd!', 'coqytonar@mailinator.com', 0, 'admin', '2024-02-16 10:16:47'),
(49, 'hyzipat', 'Pa$$w0rd', 'tafus@mailinator.com', 1, 'admin', '2024-02-16 10:17:02'),
(50, 'fejaqyr', 'Pa$$w0rd!', 'vewu@mailinator.com', 1, 'user', '2024-04-16 16:50:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `careers`
--
ALTER TABLE `careers`
  ADD PRIMARY KEY (`careers_id`);

--
-- Indexes for table `news_and_events`
--
ALTER TABLE `news_and_events`
  ADD PRIMARY KEY (`news_events_id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `careers`
--
ALTER TABLE `careers`
  MODIFY `careers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `news_and_events`
--
ALTER TABLE `news_and_events`
  MODIFY `news_events_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
